# Data Analytics Project 1: Data Cleaning & Preparation
**Organization:** DecodeLabs  
**Core Framework:** The Architecture of Data Integrity  
**Tooling Environment:** Microsoft Excel  

---

## 1. Executive Summary
In corporate data environments, poor data quality represents a severe financial drain, costing organizations an estimated 15% to 25% of their annual revenue, with an average annual loss of $12.9 million. This project transforms a raw, noisy transactional dataset consisting of 1,200 records into a production-ready, verified "Gold Standard" source of truth. 

By prioritizing backend **Data Integrity** over cosmetic visualizations, this project implements a rigorous data scrubbing pipeline to ensure that all downstream business intelligence, predictive modeling, and executive dashboards are constructed on a foundation of absolute accuracy.

---

## 2. Core Project Objectives & Deliverables
* **Strategic Imputation:** Resolve missing structural values using analytical logic without deploying listwise deletions that diminish statistical power.
* **Integrity Auditing:** Establish a strict unique transaction standard, guaranteeing a 0% error rate regarding duplicate entries.
* **Structural Standardization:** Uniformly align inconsistent textual, chronological, and monetary attributes to single corporate data standards.
* **Audit Trail Compilation:** Produce a transparent, permanent change log capturing all pipeline modifications ("*If it isn't documented, it didn't happen*").

---

## 3. Dataset Architecture
* **Source Filename:** `Dataset for Data Analytics.xlsx`
* **Total Records:** 1,200 transactional observations
* **Total Target Features:** 14 relational columns
* **Column Inventory:**
  1. `OrderID` (Primary Key / Unique Textual Identifier)
  2. `Date` (Temporal field)
  3. `CustomerID` (Alphanumeric customer entity tag)
  4. `Product` (Categorical inventory description)
  5. `Quantity` (Discrete integers representing order volume)
  6. `UnitPrice` (Continuous financial metric representing individual item cost)
  7. `ShippingAddress` (Physical address text string)
  8. `PaymentMethod` (Categorical settlement medium)
  9. `OrderStatus` (Operational processing lifecycle state)
  10. `TrackingNumber` (Unique alphanumeric logistics reference code)
  11. `ItemsInCart` (Discrete integer count)
  12. `CouponCode` (Categorical promotional text identifier - *Contains Data Gaps*)
  13. `ReferralSource` (Categorical digital acquisition channel)
  14. `TotalPrice` (Computed financial metric representing total transaction revenue)

---

## 4. Phase-by-Phase Cleaning Methodology

### Phase 1: Strategic Imputation (Handling Data Gaps)
An initial diagnostic audit of the raw matrix revealed 309 missing values located exclusively within the `CouponCode` column. Dropping these rows completely (*Listwise Deletion*) was rejected as it would artificially diminish sample size and introduce statistical bias.
* **The Logic:** Because `CouponCode` represents nominal, categorical text variables, the statistical **Mode** (the most frequently occurring observation) was determined to be the mathematically correct fill value.
* **Excel Execution Steps:**
  1. Extracted the dataset mode by executing the following array formula in an isolated workspace cell:
     `=INDEX(L2:L1201, MODE(MATCH(L2:L1201, L2:L1201, 0)))`
     *The calculation identified `FREESHIP` as the dominant non-null parameter.*
  2. Selected the entire range of Column L (`CouponCode`).
  3. Invoked the **Go To Special** panel using `Ctrl + G` -> selected the `Special...` button -> highlighted the `Blanks` radio control -> clicked `OK`. This isolated all 309 empty blocks simultaneously.
  4. Typed `FREESHIP` into the active field and executed `Ctrl + Enter` to broadcast the imputation uniformly across the selected blanks.

### Phase 2: The Integrity Audit (One Truth, One Record)
To prevent inflated transaction counts and guarantee complete unique identity across the table, a transactional auditing gate was established on the primary key feature.
* **The Logic:** Individual `OrderID` occurrences must function as a strict primary key with zero redundancy.
* **Excel Execution Steps:**
  1. Selected Column A (`OrderID`).
  2. Navigated to the ribbon menu: `Home` -> `Conditional Formatting` -> `Highlight Cells Rules` -> `Duplicate Values`.
  3. Configured a light red fill format to instantly flag overlapping records.
  4. The system validated that zero text rows lit up, confirming a 100% unique transaction distribution across all 1,200 events.

### Phase 3: Speak One Language (Standardization Gates)
To convert the processed observations into corporate-ready assets, the columns were put through rigorous formatting standardization filters.

#### 3.1 Text & Whitespace Scrubbing
Erratic manual data entry frequently introduces accidental trailing/leading spaces and unpredictable text mutations (e.g., lowercase vs uppercase mix-ups) which break index mappings and pivot sorting.
* **Excel Execution Steps:**
  1. Injected a temporary helper column next to Column D (`Product`).
  2. Applied a nested clean-and-casing utility formula in cell `E2`:
     `=TRIM(PROPER(D2))`
  3. Dragged the fill handle downward to flash-fill the formula to row 1201.
  4. Copied the cleaned output range (`Ctrl + C`), selected the original column range, and applied `Right-Click` -> **Paste as Values (123)** to lock the sanitized text in place. 
  5. Deleted the temporary column. This exact workflow was executed on all text parameters (`PaymentMethod`, `OrderStatus`, `ReferralSource`).

#### 3.2 ISO 8601 Date Standardization
Mixed historical date formats disrupt chronological trend calculations. The data contract requires total alignment to international standard specifications.
* **Excel Execution Steps:**
  1. Highlighted Column B (`Date`).
  2. Opened the cell configuration dashboard via `Ctrl + 1`.
  3. Under the *Category* index, scrolled to the base and selected **Custom**.
  4. Input the precise string literal code inside the *Type* dialogue window:
     `yyyy-mm-dd`
  5. Applied changes, establishing a 0% date format error rate (e.g., converting all text/mixed records into uniform configurations such as `2023-01-04`).

#### 3.3 Financial Numeric Precision
Currency values must match a continuous uniform specification layout to guarantee error-free mathematical aggregations.
* **Excel Execution Steps:**
  1. Selected columns F (`UnitPrice`) and N (`TotalPrice`) simultaneously using the `Ctrl` click selector tool.
  2. Launched cell formatting properties (`Ctrl + 1`) and chose the **Number** category structure.
  3. Configured the parameters to strictly enforce a standard of **2 decimal places**.
  4. Saved modifications, ensuring complete decimal alignment.

---

## 5. Comprehensive Pipeline Change Log
This repository log acts as the verified audit trail ensuring every structural adjustment is formally documented.

| Change ID | Feature Target | Action Implemented | Statistical/Data Justification | Status |
| :--- | :--- | :--- | :--- | :--- |
| **CR001** | `CouponCode` | Mass-imputed missing values using column mode calculation (`FREESHIP`). | Preserved 309 operational text rows; prevented listwise data size reduction. | **Resolved** |
| **CR002** | `OrderID` | Deployed Conditional Formatting duplicate filters. | Documented a 0% duplication error rate, securing the unique identity constraint. | **Resolved** |
| **CR003** | `Product`, `OrderStatus`, `PaymentMethod` | Programmed nested `=TRIM(PROPER())` values, pasting outcomes over raw data. | Eliminated invisible trailing/leading whitespaces and normalized random letter casings. | **Resolved** |
| **CR004** | `Date` | Enforced strict custom `yyyy-mm-dd` configuration rules. | Restructured chronological markers to the universal ISO 8601 standard. | **Resolved** |
| **CR005** | `UnitPrice`, `TotalPrice` | Programmed cells to the Number structure restricted to 2 decimal points. | Guaranteed uniform mathematical alignment for downstream financial calculations. | **Resolved** |

---

## 6. Verification & Data Integrity Sign-Off
Following the execution of the Excel data cleaning pipeline, the updated repository was put through a final audit sweep. The diagnostic results confirm:
1. **Missing Elements:** 0 blank fields remain across all 14 metrics.
2. **Duplication Error Rate:** Exactly 0.00% primary identifier collisions.
3. **Format Alignment:** 100% compliance with ISO 8601 chronology and 2-decimal financial parameters.

The spreadsheet has successfully transitioned from noisy, raw transactional data into a certified **"Gold Standard"** digital asset, fully satisfying the qualification parameters required to unlock the next analytical module.